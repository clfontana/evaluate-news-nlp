//const fetch = require('node-fetch');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

const FormData = require('form-data');
const dotenv = require('dotenv');
dotenv.config({ path: './process.env' });
const application_key = process.env.API_KEY;

var path = require('path');
const express = require('express');
const mockAPIResponse = require('./mockAPI.js');

const app = express();

app.use(express.static('dist'));

console.log(__dirname);

console.log(`Your API key is ${process.env.API_KEY}`);

app.get('/', function (req, res) {
    res.sendFile('dist/index.html')
    // res.sendFile(path.resolve('src/client/views/index.html'))
});

// designates what port the app will listen to for incoming requests
app.listen(8080, function () {
    console.log('Example app listening on port 8080!');
});

// only for test
app.get('/test', function (req, res) {
    res.send(mockAPIResponse);
});

/**
 * @description post data to retrieve info from meaningcloud api
 * @param {*} req 
 * @param {*} res 
 */
async function fetchMeaningcloud(req, res){
    console.log('meaningcloud -> name: ' + req.query.name);

    let content = '';
    let rawResponse = '';
    let formBody = [];

    let encodedKey   = '';
    let encodedValue = '';

    formBody.push(encodeURIComponent('key')  + '='  + encodeURIComponent(this.application_key));
    formBody.push(encodeURIComponent('lang') + '='  + encodeURIComponent("auto"));
    formBody.push(encodeURIComponent('url')  + '='  + encodeURIComponent(req.query.name));
    formBody = formBody.join("&");
    
    try{
        /*
        rawResponse = await fetch("http://api.meaningcloud.com/sentiment-2.1", {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: formBody,
        }).then(function (res) { 
            return res.json(); 
        }).then(data => {

            console.log(data);

            content =  `General info:\n`;
            content += `subjectivity: ${data.subjectivity}\n`;
            content += `confidence: ${data.confidence}\n`;            
            content += `score_tag: ${data.score_tag}\n`;

            let dataSentences = data.sentence_list;
            
            if (dataSentences && dataSentences.length > 0){
                content +=  `Sample detail:\n`;
                content += `confidence: ${dataSentences[0].confidence}\n`;
                content += `score_tag:  ${dataSentences[0].score_tag}\n`;
                content += `text:  ${dataSentences[0].text}\n`;
            }

           return content;
        });
        //console.log(rawResponse);
        */
    }catch(error){
        console.log(error);
        content = error;
    }

}

/**
 * @description post data to retrieve info from meaningcloud api
 * @param {*} req 
 * @param {*} res 
 */
const postData = async (req, res) => {
    console.log('meaningcloud -> name: ' + req.query.name);

    let content = '';
    let formBody = [];

    let encodedKey   = '';
    let encodedValue = '';

    let urlEncoded = new URLSearchParams();
    urlEncoded.append('key', application_key);
    urlEncoded.append('lang', "auto");
    urlEncoded.append('url', req.query.name);

    /*
    formBody.push(encodeURIComponent('key')  + '='  + encodeURIComponent(application_key));
    formBody.push(encodeURIComponent('lang') + '='  + encodeURIComponent("auto"));
    formBody.push(encodeURIComponent('url')  + '='  + encodeURIComponent(req.query.name));
    formBody = formBody.join("&");
    */
    console.log(application_key);
    console.log(req.query.name);    

    const response = await fetch("http://api.meaningcloud.com/sentiment-2.1", {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: urlEncoded,
        redirect: 'follow'
    });

    try{
        const data = await response.json();
        
        //console.log(data);
        /*
        content =  `General info:\n`;
        content += `subjectivity: ${data.subjectivity}\n`;
        content += `confidence: ${data.confidence}\n`;            
        content += `score_tag: ${data.score_tag}\n`;

        let dataSentences = data.sentence_list;
            
        if (dataSentences && dataSentences.length > 0){
            content +=  `Sample detail:\n`;
            content += `confidence: ${dataSentences[0].confidence}\n`;
            content += `score_tag:  ${dataSentences[0].score_tag}\n`;
            content += `text:  ${dataSentences[0].text}\n`;
        }
        */
        return {"message" : "bbbb"};
    }catch(error){
        console.log('error', error);
    }
}

app.get('/meaningcloud', sendDataToClient);

function sendDataToClient(req, res){
    //res.setHeader('content-type', 'application/json');
    let obj = {"message" : "bbbb"};
    //res.send(fetchMeaningcloud(req, res));
    res.send(obj);

}
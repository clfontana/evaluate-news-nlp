import { handleSubmit } from "./formHandler";

describe("Testing formHandler", () => {

    test("Check if handleSubmit() is defined", () =>{
        expect(handleSubmit).toBeDefined();
    });

})
const fetch = require('node-fetch');
const FormData = require('form-data');
const dotenv = require('dotenv');
dotenv.config({ path: './process.env' });
const application_key = process.env.API_KEY;

var path = require('path');
const express = require('express');
const mockAPIResponse = require('./mockAPI.js');

const app = express();

app.use(express.static('dist'));

console.log(__dirname);

console.log(`Your API key is ${process.env.API_KEY}`);

app.get('/', function (req, res) {
    res.sendFile('dist/index.html')
    // res.sendFile(path.resolve('src/client/views/index.html'))
});

// designates what port the app will listen to for incoming requests
app.listen(8080, function () {
    console.log('Example app listening on port 8080!');
});

app.get('/test', function (req, res) {
    res.send(mockAPIResponse);
});

app.get('/meaningcloud', function(req,res){
    console.log('meaningcloud -> ' + req.query.name);
    let result = '';
    const formData  = new FormData('multipart/form-data');

    //formData.append('key', this.application_key, 'string');
    //formData.append('lang', 'auto', 'string');
    //formData.append('txt', req.query.name, 'string');

    fetch('https://api.meaningcloud.com/sentiment-2.1', {
        mode: 'no-cors',
        method: POST,
        headers: {
          'Content-Type': 'x-www-form-urlencoded'
        },
        body: formData,
    }).then(function(response) {
        result = response;
        console.log(response.status)
        console.log("response");
        console.log(response)
    });

    res.send(result);
});

import { handleSubmit } from "./formHandler";

describe("Testing formHandlerw", () => {

    test("Check if handleSubmit() is defined", () =>{
        expect(handleSubmit).toBeDefined();
    });

})